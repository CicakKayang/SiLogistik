<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pinjam extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'id', 'aset_id', 'ormawa_id', 'nama_peminjam', 'no_hp'
    ];

    public function aset()
    {
        return $this->belongsTo(Aset::class);
    }

    public function ormawa()
    {
        return $this->belongsTo(Ormawa::class);
    }
}
