<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Aset;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AsetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $asets = Aset::all();
        return view('asets.index', [
            'asets' => $asets
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('asets.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $asets = new Aset();
        $asets->nama_barang     = $request->nama_barang;
        $asets->jumlah = $request->jumlah;
        $asets->kondisi = $request->kondisi;
        $asets->jumlah = $request->jumlah;
        $asets->keterangan = $request->keterangan;
        $asets->save();
        return redirect()->route('asets.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $asets = Aset::find($id);
        return view('asets.edit', ['asets' => $asets]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $asets = Aset::findOrFail($id);
        $asets->nama_barang = $request->nama_barang;
        $asets->jumlah = $request->jumlah;
        $asets->kondisi = $request->kondisi;
        $asets->jumlah = $request->jumlah;
        $asets->keterangan = $request->keterangan;
        $asets->save();
        return redirect()->route('asets.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy($id)
    {
        $asets = Aset::findOrFail($id);
        $asets->delete();

        return redirect('asets');
    }

    public function generatePdf()
    {
        $asets = Aset::get();
        $pdf = PDF::loadView('asets.asets_pdf', ['asets' => $asets]);
        return $pdf->download('data_inventaris' . time() . rand('999', '9999') . '.pdf');
    }
}
