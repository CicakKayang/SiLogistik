<?php

namespace App\Http\Controllers;

use App\Models\Pinjam;
use App\Models\Aset;
use App\Models\Ormawa;
use Illuminate\Http\Request;

class PinjamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $pinjams = Pinjam::all();
        return view('pinjams.index', ['pinjams' => $pinjams]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $asets = Aset::all()->sortBy('nama_barang');
        $ormawas = Ormawa::all()->sortBy('nama_ormawa');
        return view('pinjams.create', compact('asets', 'ormawas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $pinjams = new Pinjam();
        $pinjams->aset_id = $request->aset_id;
        $pinjams->ormawa_id = $request->ormawa_id;
        $pinjams->nama_peminjam = $request->nama_peminjam;
        $pinjams->no_hp = $request->no_hp;
        $pinjams->save();
        return redirect()->route('pinjams.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pinjams = Pinjam::find($id);
        $asets = Aset::all()->sortBy('nama_barang');
        $ormawas = Ormawa::all()->sortBy('nama_ormawa');
        return view('pinjams.edit', ['pinjams' => $pinjams], compact('asets', 'ormawas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $pinjams = Pinjam::findOrFail($id);
        $pinjams->aset_id = $request->aset_id;
        $pinjams->ormawa_id = $request->ormawa_id;
        $pinjams->nama_peminjam = $request->nama_peminjam;
        $pinjams->no_hp = $request->no_hp;
        $pinjams->save();
        return redirect()->route('pinjams.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pinjams = Pinjam::find($id);
        $pinjams->delete();

        return redirect('pinjams');
    }
}
