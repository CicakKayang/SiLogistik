@extends('adminlte::page')

@section('title', 'Tambah Asset')

@section('content_header')
<h1 class="m-0 text-dark">Tambah Asset</h1>
@stop

@section('content')
<form action="{{route('asets.store')}}" method="post">
    @csrf
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="form-group">
                        <label for="exampleInputNamaBarang">Nama Barang</label>
                        <input type="text" class="form-control @error('nama_barang') is-invalid @enderror" id="exampleInputNamaBarang" placeholder="Nama Barang" name="nama_barang" value="{{old('nama_barang')}}">
                        @error('nama_barang') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                    <div class="form-group">
                        <label for="exampleInputJumlah">Jumlah Barang</label>
                        <input type="int" class="form-control @error('jumlah') is-invalid @enderror" id="exampleInputJumlah" placeholder="Masukkan Jumlah Barang" name="jumlah" value="{{old('jumlah')}}">
                        @error('jumlah') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                    <div class="form-group">
                        <label for="exampleInputKondisi">Kondisi</label>
                        <select name="kondisi" class="form-control @error('kondisi') is-invalid @enderror" id="exampleInputKondisi">
                            <option value="" disabled selected>--Pilih Status--</option>
                            <option value="Baik">Baik</option>
                            <option value="Rusak">Rusak</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputKeterangan">Keterangan</label>
                        <input type="text" class="form-control @error('keterangan') is-invalid @enderror" id="exampleInputKeterangan" placeholder="Keterangan" name="keterangan" value="-">
                        @error('keterangan') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="{{route('asets.index')}}" class="btn btn-default">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
    @stop