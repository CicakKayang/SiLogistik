@extends('adminlte::page')

@section('title', 'Asset')

@section('content_header')
<h1 class="m-0 text-dark">Data Inventaris KSR PMI Unit UNISNU</h1>
@stop

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <a href="{{route('asets.create')}}" class="btn btn-primary mb-2">
                    Tambah
                </a>
                <a href="{{ route('generatePdf') }}" class="btn btn-warning mb-2">
                    <i data-feather="printer"></i> Cetak PDF
                </a>
                <table class="table table-hover table-bordered table-stripped" id="example2">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Kondisi</th>
                            <th>Keterangan</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($asets as $k => $aset)
                        <tr>
                            <td>{{ $k+1 }}</td>
                            <td>{{ $aset->nama_barang }}</td>
                            <td>{{ $aset->jumlah }}</td>
                            <td>{{ $aset->kondisi }}</td>
                            <td>{{ $aset->keterangan }}</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="{{ route('asets.edit', $aset)}}" class="btn btn-primary btn-xs">
                                        Edit
                                    </a>
                                    <form action="{{ route('asets.destroy', $aset['id']) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <input type="submit" value="Delete" class="btn btn-danger btn-xs" onclick="confirm('Yakin?')">
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@stop

@push('js')
<script>
    $('#example2').DataTable({
        "responsive": true,
    });
</script>
@endpush