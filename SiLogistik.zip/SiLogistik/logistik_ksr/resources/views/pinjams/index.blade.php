@extends('adminlte::page')

@section('title', 'Data Peminjaman Asset')

@section('content_header')
<h1 class="m-0 text-dark">Data Peminjaman Asset</h1>
@stop

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <a href="{{route('pinjams.create')}}" class="btn btn-primary mb-2">
                    Tambah
                </a>
                <table class="table table-hover table-bordered table-stripped" id="example2">
                    <thead>
                        <tr>
                            <th scope="col">No.</th>
                            <th scope="col">Nama Barang</th>
                            <th scope="col">Ormawa</th>
                            <th scope="col">Nama Peminjam</th>
                            <th scope="col">No. HP</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pinjams as $q => $pinjam)
                        <tr>
                            <td>{{ $q+1 }}</td>
                            <td>{{ $pinjam->aset->nama_barang }}</td>
                            <td>{{ $pinjam->ormawa->nama_ormawa }}</td>
                            <td>{{ $pinjam->nama_peminjam }}</td>
                            <td>0{{ $pinjam->no_hp }}</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="{{route('pinjams.edit', $pinjam)}}" class="btn btn-primary btn-xs">
                                        Edit
                                    </a>
                                    <form action="{{ route('pinjams.destroy', $pinjam['id']) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <input type="submit" value="Delete" class="btn btn-danger btn-xs" onclick="confirm('Yakin?')">
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@stop

@push('js')
<script>
    $('#example2').DataTable({
        "responsive": true,
    });
</script>
@endpush