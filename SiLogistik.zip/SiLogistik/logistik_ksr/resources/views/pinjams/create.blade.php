@extends('adminlte::page')

@section('title', 'Tambah Peminjam')

@section('content_header')
<h1 class="m-0 text-dark">Tambah Daftar Peminjam</h1>
@stop

@section('content')
<form action="{{route('pinjams.store')}}" method="post">
    @csrf
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="form-group">
                        <label for="exampleInputAsetId">Barang yang dipinjam</label>
                        <select class="form-control" id="exampleInputAsetId" name="aset_id">
                            <option value="" disabled selected>--Pilih Barang--</option>
                            @foreach ($asets as $aset)
                            <option value="{{ $aset->id }}">{{ $aset->nama_barang }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputOrmawaId">Ormawa Peminjam</label>
                        <select class="form-control" id="exampleInputOrmawaId" name="ormawa_id">
                            <option value="" disabled selected>--Pilih Ormawa--</option>
                            @foreach ($ormawas as $ormawa)
                            <option value="{{ $ormawa->id }}">{{ $ormawa->nama_ormawa }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputNamaPeminjam">Nama Peminjam</label>
                        <input type="text" class="form-control @error('nama_peminjam') is-invalid @enderror" id="exampleInputNamaPeminjam" placeholder="Masukkan Nama Peminjam" name="nama_peminjam" value="{{old('nama_peminjam')}}">
                        @error('nama_peminjam') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                    <div class="form-group">
                        <label for="exampleInputNoHp">No. HP</label>
                        <input type="text" class="form-control @error('no_hp') is-invalid @enderror" id="exampleInputNoHp" placeholder="Masukkan Nomor HP" name="no_hp" value="{{old('no_hp')}}">
                        @error('no_hp') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="{{route('pinjams.index')}}" class="btn btn-default">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
    @stop