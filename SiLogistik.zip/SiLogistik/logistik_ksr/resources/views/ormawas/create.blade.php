@extends('adminlte::page')

@section('title', 'Tambah Ormawa')

@section('content_header')
<h1 class="m-0 text-dark">Tambah Daftar Ormawa</h1>
@stop

@section('content')
<form action="{{route('ormawas.store')}}" method="post">
    @csrf
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="form-group">
                        <label for="exampleInputNamaOrmawa">Nama Ormawa</label>
                        <input type="text" class="form-control @error('nama_ormawa') is-invalid @enderror" id="exampleInputNamaOrmawa" placeholder="Nama Ormawa" name="nama_ormawa" value="{{old('nama_ormawa')}}">
                        @error('nama_ormawa') <span class="text-danger">{{$message}}</span> @enderror
                    </div>

                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="{{route('ormawas.index')}}" class="btn btn-default">
                        Batal
                    </a>
                </div>
            </div>
        </div>
    </div>
    @stop