@extends('adminlte::page')

@section('title', 'Daftar Ormawa UNISNU')

@section('content_header')
<h1 class="m-0 text-dark">Daftar Ormawa UNISNU</h1>
@stop

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <a href="{{route('ormawas.create')}}" class="btn btn-primary mb-2">
                    Tambah
                </a>
                <table class="table table-hover table-bordered table-stripped" id="example2">
                    <thead>
                        <tr>
                            <th scope="col">No.</th>
                            <th scope="col">Nama Ormawa</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($ormawas as $a => $ormawa)
                        <tr>
                            <td>{{ $a+1 }}</td>
                            <td>{{ $ormawa->nama_ormawa }}</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="{{route('ormawas.edit', $ormawa)}}" class="btn btn-primary btn-xs">
                                        Edit
                                    </a>
                                    <form action="{{ route('ormawas.destroy', $ormawa['id']) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <input type="submit" value="Delete" class="btn btn-danger btn-xs" onclick="confirm('Yakin?')">
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@stop

@push('js')
<script>
    $('#example2').DataTable({
        "responsive": true,
    });
</script>
@endpush