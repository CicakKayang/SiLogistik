<?php

namespace Database\Factories;

use App\Models\Aset;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Aset>
 */
class AsetFactory extends Factory
{
    protected $model = Aset::class;

    public function definition()
    {
        return [
            'nama_barang',
            'jumlah',
            'kondisi',
            'keterangan'

        ];
    }
}
