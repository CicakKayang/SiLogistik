<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AsetController;
use App\Http\Controllers\OrmawaController;
use App\Http\Controllers\PinjamController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return redirect()->route('login');
});

Route::resource('asets', \App\Http\Controllers\AsetController::class)->middleware('auth');;
Route::resource('ormawas', \App\Http\Controllers\OrmawaController::class)->middleware('auth');;
Route::resource('pinjams', \App\Http\Controllers\PinjamController::class)->middleware('auth');;

Route::get('generatePdf', [App\Http\Controllers\AsetController::class,
'generatePdf'])->name('generatePdf');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', function() {
    return view('home');
})->name('home')->middleware('auth');

Route::resource('users', \App\Http\Controllers\UserController::class)
    ->middleware('auth');
